var socket = new WebSocket("ws://192.168.0.16:8001");

let turno = 1;
let fichas = ["O", "X"];
let puestas = 0;
let partidaAcabada = false;
let textoVictoria = document.getElementById("textoVictoria");
let botones = Array.from(document.getElementsByTagName("button"));

botones.forEach(x => x.addEventListener("click", ponerFicha));


let estadoPartida = estado();
if (estadoPartida == 0) {
    if (puestas < 9) {
        ia();
        puestas += 1;
        estadoPartida = estado();
    } else {
        textoVictoria.innerHTML = "EMPATE"
        partidaAcabada = true;
        textoVictoria.style.visibility = "visible";
    }
}


function ponerFicha(event) {
    let botonPulsado = event.target;
    if (!partidaAcabada && botonPulsado.innerText == "") {
        botonPulsado.innerText = fichas[turno];
        puestas += 1;

        let posicion = botones.indexOf(botonPulsado) + 1;
        textoVictoria.style.visibility = "visible";
        socket.send(JSON.stringify({ nombre: `Usuario_Web`, mensaje: `${posicion}` }));

        
        let estadoPartida = estado();
        if (estadoPartida == 0) {
            if (puestas < 9) {
                ia();
                puestas += 1;
                estadoPartida = estado();
            } else {
                textoVictoria.innerHTML = "EMPATE"
                partidaAcabada = true;
                textoVictoria.style.visibility = "visible";
            }
        }
        
    }
}

function mostrarMensajeVictoria(ficha) {
    textoVictoria.innerHTML = `JUGADOR CON ${ficha} GANA!`;
    partidaAcabada = true;
    textoVictoria.style.visibility = "visible";
}

function estado() {
    posicionVictoria = 0;
    nEstado = 0;

    function sonIguales(...args) {
        valores = args.map(x => x.innerText);
        if (valores[0] != "" && valores.every((x, i, arr) => x === arr[0])) {
            args.forEach(x => x.style.backgroundColor = "Gold")
            return true;
        }
        else {
            return false;
        }
    }

    if (sonIguales(botones[0], botones[1], botones[2])) {
        posicionVictoria = 1;
        mostrarMensajeVictoria(botones[0].innerText);
    }
    else if (sonIguales(botones[3], botones[4], botones[5])) {
        posicionVictoria = 2;
        mostrarMensajeVictoria(botones[3].innerText);
    }
    else if (sonIguales(botones[6], botones[7], botones[8])) {
        posicionVictoria = 3;
        mostrarMensajeVictoria(botones[6].innerText);
    }
    else if (sonIguales(botones[0], botones[3], botones[6])) {
        posicionVictoria = 4;
        mostrarMensajeVictoria(botones[0].innerText);
    }
    else if (sonIguales(botones[1], botones[4], botones[7])) {
        posicionVictoria = 5;
        mostrarMensajeVictoria(botones[1].innerText);
    }
    else if (sonIguales(botones[2], botones[5], botones[8])) {
        posicionVictoria = 6;
        mostrarMensajeVictoria(botones[2].innerText);
    }
    else if (sonIguales(botones[0], botones[4], botones[8])) {
        posicionVictoria = 7;
        mostrarMensajeVictoria(botones[0].innerText);
    }
    else if (sonIguales(botones[2], botones[4], botones[6])) {
        posicionVictoria = 8;
        mostrarMensajeVictoria(botones[2].innerText);
    }
    if (posicionVictoria > 0) {
        nEstado = -1;
    }
    return nEstado;
}


function ia() {

        // Establece el manejador de eventos onmessage para recibir mensajes del servidor
        socket.onmessage = function(event) {
            var data = JSON.parse(event.data);
            // Coloca el mensaje del servidor en textoVictoria

            let posicion = data.mensaje;

            if (posicion >= 1 && posicion <= 9) {
                let boton = botones[posicion - 1]; // Restamos 1 para que la posición sea 0-indexed
                if (boton.innerText === "") {
                    boton.innerText = "O";
                }
            } else if (posicion == 0){
                location.reload();
            }
        };

}

function enviarReset() {
    socket.send(JSON.stringify({ nombre: "Usuario_Web", mensaje: "0" }));
    location.reload();
}
